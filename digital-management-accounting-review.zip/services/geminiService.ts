import { GoogleGenAI } from "@google/genai";
import { Question } from "../types";

// Initialize the Gemini client only if the key exists to prevent errors on load
const apiKey = process.env.API_KEY;
const ai = apiKey ? new GoogleGenAI({ apiKey }) : null;

export const getAIExplanation = async (question: Question): Promise<string> => {
  if (!ai) {
    return "API Key is missing. Please configure the environment variable to use AI features.";
  }

  const prompt = `
    You are an expert professor in Digital Management Accounting (数字化管理会计).
    Please explain why the answer is correct for the following question in Chinese.
    Keep it concise (under 100 words) and easy to understand.
    
    Question Type: ${question.type}
    Question: ${question.text}
    Options: ${question.options ? question.options.join(', ') : 'True/False'}
    Correct Answer: ${question.correctAnswer}
  `;

  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: prompt,
    });
    return response.text || "无法获取解释，请稍后再试。";
  } catch (error) {
    console.error("Gemini API Error:", error);
    return "AI 服务暂时不可用。";
  }
};