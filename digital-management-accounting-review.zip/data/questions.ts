import { Question, QuestionType } from '../types';

export const questions: Question[] = [
  // ==========================================
  // 第一部分：单选题
  // ==========================================
  {
    id: 1,
    type: QuestionType.SINGLE_CHOICE,
    text: "下列关于标准成本的说法中，不正确的是( )。",
    options: [
      "标准成本是一种目标成本",
      "标准成本是一种历史成本",
      "标准成本可以用来评价业绩",
      "标准成本可以作为预算编制的基础"
    ],
    correctAnswer: "B"
  },
  {
    id: 2,
    type: QuestionType.SINGLE_CHOICE,
    text: "管理会计与财务会计最本质的区别在于( )。",
    options: ["服务对象不同", "会计主体不同", "核算依据不同", "核算方法不同"],
    correctAnswer: "A"
  },
  {
    id: 3,
    type: QuestionType.SINGLE_CHOICE,
    text: "在变动成本法下，固定性制造费用应当列作( )。",
    options: ["非生产成本", "期间成本", "产品成本", "直接成本"],
    correctAnswer: "B"
  },
  {
    id: 4,
    type: QuestionType.SINGLE_CHOICE,
    text: "下列成本项目中，属于酌量性固定成本的是( )。",
    options: ["固定资产折旧", "管理人员薪金", "广告费", "房屋租金"],
    correctAnswer: "C"
  },
  {
    id: 5,
    type: QuestionType.SINGLE_CHOICE,
    text: "某企业只生产一种产品，单价6元，单位变动成本4.5元，固定成本总额3000元，则保本销售量为( )。",
    options: ["2000件", "1500件", "3000件", "500件"],
    correctAnswer: "A"
  },
  {
    id: 6,
    type: QuestionType.SINGLE_CHOICE,
    text: "不受现有费用项目和开支水平限制，并以零为基础编制的预算是( )。",
    options: ["弹性预算", "固定预算", "零基预算", "滚动预算"],
    correctAnswer: "C"
  },
  {
    id: 7,
    type: QuestionType.SINGLE_CHOICE,
    text: "下列指标中，属于非财务业绩评价指标的是( )。",
    options: ["投资报酬率", "经济增加值", "客户满意度", "息税前利润"],
    correctAnswer: "C"
  },
  {
    id: 8,
    type: QuestionType.SINGLE_CHOICE,
    text: "平衡计分卡(BSC)的四个维度不包括( )。",
    options: ["财务维度", "客户维度", "内部业务流程维度", "社会责任维度"],
    correctAnswer: "D"
  },
  {
    id: 9,
    type: QuestionType.SINGLE_CHOICE,
    text: "作业成本法(ABC)分配间接费用的依据是( )。",
    options: ["生产工时", "机器工时", "成本动因", "直接材料成本"],
    correctAnswer: "C"
  },
  {
    id: 10,
    type: QuestionType.SINGLE_CHOICE,
    text: "在相关范围内，单位变动成本( )。",
    options: ["随产量增加而减少", "随产量增加而增加", "保持不变", "不一定"],
    correctAnswer: "C"
  },

  // ==========================================
  // 第二部分：判断题
  // ==========================================
  {
    id: 181,
    type: QuestionType.JUDGMENT,
    text: "预算调整重点应放在预算执行中出现的重要的、非正常的、不符合常规的关键性差异方面。",
    options: ["对", "错"],
    correctAnswer: "A"
  },
  {
    id: 182,
    type: QuestionType.JUDGMENT,
    text: "预算考核侧重对财务指标的考核，是企业绩效考核的重要组成部分。",
    options: ["对", "错"],
    correctAnswer: "B"
  },
  {
    id: 183,
    type: QuestionType.JUDGMENT,
    text: "企业财务管理部门应当利用报表监控预算执行情况，及时提供预算执行进度、执行差异及其对企业预算目标的影响。",
    options: ["对", "错"],
    correctAnswer: "A"
  },
  {
    id: 184,
    type: QuestionType.JUDGMENT,
    text: "预算考核主体和考核对象的界定应坚持上级考核下级、逐级考核、预算执行与预算考核相互分离的原则。",
    options: ["对", "错"],
    correctAnswer: "A"
  },
  {
    id: 185,
    type: QuestionType.JUDGMENT,
    text: "沉没成本属于相关成本，在决策时必须予以考虑。",
    options: ["对", "错"],
    correctAnswer: "B"
  },

  // ==========================================
  // 第三部分：计算题（仍按单选处理）
  // ==========================================
  {
    id: 250,
    type: QuestionType.SINGLE_CHOICE,
    text: "(计算题) 若2019年预计销售收入为1200万元，采用高低点法预测资金占用额为( )。",
    options: ["1020 万元", "1100 万元", "1120 万元", "1140 万元"],
    correctAnswer: "C"
  },
  {
    id: 251,
    type: QuestionType.SINGLE_CHOICE,
    text: "(计算题) 采用约当产量法计算完工产品成本为( )。",
    options: ["120000", "125000", "138000", "142000"],
    correctAnswer: "C"
  },
  {
    id: 252,
    type: QuestionType.SINGLE_CHOICE,
    text: "(计算题) 固定成本500万元，变动成本率60%，目标利润100万元，则销售收入应为( )。",
    options: ["1000万元", "1250万元", "1500万元", "2000万元"],
    correctAnswer: "C"
  },
  {
    id: 253,
    type: QuestionType.SINGLE_CHOICE,
    text: "(计算题) 投资额100万元，年现金净流量30万元，静态回收期为( )。",
    options: ["3年", "3.33年", "4年", "5年"],
    correctAnswer: "B"
  },
  {
    id: 254,
    type: QuestionType.SINGLE_CHOICE,
    text: "(计算题) 直接人工效率差异为( )。",
    options: ["8000元 (不利)", "8000元 (有利)", "4000元 (不利)", "4000元 (有利)"],
    correctAnswer: "A"
  }
    {
    id: 31,
    type: QuestionType.SINGLE_CHOICE,
    text: "下列各项中，不属于相关成本的是( )。",
    options: ["机会成本", "沉没成本", "付现成本", "可避免成本"],
    correctAnswer: "B"
  },
  {
    id: 32,
    type: QuestionType.SINGLE_CHOICE,
    text: "在本量利分析中，贡献毛益是指( )。",
    options: [
      "销售收入减变动成本后的余额",
      "销售收入减固定成本后的余额",
      "销售收入减总成本后的余额",
      "销售收入减期间成本后的余额"
    ],
    correctAnswer: "A"
  },
  {
    id: 33,
    type: QuestionType.SINGLE_CHOICE,
    text: "下列各项中，不会影响保本点变动的是( )。",
    options: ["销售单价", "单位变动成本", "固定成本总额", "销售量"],
    correctAnswer: "D"
  },
  {
    id: 34,
    type: QuestionType.SINGLE_CHOICE,
    text: "弹性预算与固定预算相比，其主要优点是( )。",
    options: [
      "编制方法简单",
      "不需要业务量预测",
      "能够适应不同业务量水平",
      "便于长期预算管理"
    ],
    correctAnswer: "C"
  },
  {
    id: 35,
    type: QuestionType.SINGLE_CHOICE,
    text: "责任会计中，利润中心的考核指标是( )。",
    options: ["成本", "利润", "投资报酬率", "剩余收益"],
    correctAnswer: "B"
  },
  {
    id: 36,
    type: QuestionType.SINGLE_CHOICE,
    text: "下列各项中，属于制造成本的是( )。",
    options: ["直接材料", "销售费用", "管理费用", "财务费用"],
    correctAnswer: "A"
  },
  {
    id: 37,
    type: QuestionType.SINGLE_CHOICE,
    text: "在完全成本法下，固定制造费用应当( )。",
    options: [
      "全部计入期间成本",
      "全部计入产品成本",
      "部分计入期间成本",
      "不予确认"
    ],
    correctAnswer: "B"
  },
  {
    id: 38,
    type: QuestionType.SINGLE_CHOICE,
    text: "企业进行短期经营决策时，最重要的成本概念是( )。",
    options: ["历史成本", "机会成本", "相关成本", "标准成本"],
    correctAnswer: "C"
  },
  {
    id: 39,
    type: QuestionType.SINGLE_CHOICE,
    text: "安全边际是指( )。",
    options: [
      "实际销售量与保本销售量之间的差额",
      "目标销售量与保本销售量之间的差额",
      "预计销售量与目标销售量之间的差额",
      "最大销售量与保本销售量之间的差额"
    ],
    correctAnswer: "A"
  },
  {
    id: 40,
    type: QuestionType.SINGLE_CHOICE,
    text: "在预算管理中，起控制作用的核心环节是( )。",
    options: ["预算编制", "预算执行", "预算分析", "预算考核"],
    correctAnswer: "B"
  },
  {
    id: 41,
    type: QuestionType.SINGLE_CHOICE,
    text: "下列预算中，属于财务预算的是( )。",
    options: ["销售预算", "生产预算", "现金预算", "直接材料预算"],
    correctAnswer: "C"
  },
  {
    id: 42,
    type: QuestionType.SINGLE_CHOICE,
    text: "标准成本法中，直接材料价格差异形成的原因主要是( )。",
    options: [
      "材料消耗数量变动",
      "材料采购价格变动",
      "生产效率变动",
      "产品设计变动"
    ],
    correctAnswer: "B"
  },
  {
    id: 43,
    type: QuestionType.SINGLE_CHOICE,
    text: "内部转移价格若采用成本基础定价，其主要缺点是( )。",
    options: [
      "容易引起部门间矛盾",
      "不利于调动供方积极性",
      "可能掩盖低效率",
      "不符合公平原则"
    ],
    correctAnswer: "C"
  },
  {
    id: 44,
    type: QuestionType.SINGLE_CHOICE,
    text: "投资回收期法的主要缺点是( )。",
    options: [
      "未考虑时间价值",
      "计算复杂",
      "无法反映风险",
      "忽略投资成本"
    ],
    correctAnswer: "A"
  },
  {
    id: 45,
    type: QuestionType.SINGLE_CHOICE,
    text: "在杜邦分析体系中，用于衡量资产使用效率的指标是( )。",
    options: ["销售净利率", "总资产周转率", "权益乘数", "净资产收益率"],
    correctAnswer: "B"
  },
  {
    id: 46,
    type: QuestionType.SINGLE_CHOICE,
    text: "作业成本法中，作业成本分配到产品的依据是( )。",
    options: ["成本动因", "资源消耗量", "生产批次", "产品数量"],
    correctAnswer: "A"
  },
  {
    id: 47,
    type: QuestionType.SINGLE_CHOICE,
    text: "下列各项中，属于战略成本管理内容的是( )。",
    options: [
      "价值链分析",
      "标准成本控制",
      "预算执行控制",
      "责任成本管理"
    ],
    correctAnswer: "A"
  },
  {
    id: 48,
    type: QuestionType.SINGLE_CHOICE,
    text: "当经营杠杆系数较大时，说明企业( )。",
    options: [
      "固定成本较低",
      "销售风险较小",
      "利润对销量变动敏感",
      "变动成本比例较高"
    ],
    correctAnswer: "C"
  },
  {
    id: 49,
    type: QuestionType.SINGLE_CHOICE,
    text: "零基预算的编制起点是( )。",
    options: ["上期预算", "历史成本", "现有资源", "零"],
    correctAnswer: "D"
  },
  {
    id: 50,
    type: QuestionType.SINGLE_CHOICE,
    text: "下列各项中，不属于预算管理原则的是( )。",
    options: ["全面性原则", "灵活性原则", "权责对等原则", "历史继承原则"],
    correctAnswer: "D"
  }

];
