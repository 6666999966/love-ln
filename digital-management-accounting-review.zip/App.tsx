import React, { useState, useMemo } from 'react';
import { questions } from './data/questions';
import { AppMode, QuizState } from './types';
import { QuestionCard } from './components/QuestionCard';
import { ReviewList } from './components/ReviewList';
import { BookOpen, PlayCircle, BarChart3, RotateCcw, Trophy } from 'lucide-react';
import { Button } from './components/Button';

const INITIAL_STATE: QuizState = {
  currentQuestionIndex: 0,
  score: 0,
  answers: {},
  isFinished: false
};

const App: React.FC = () => {
  const [mode, setMode] = useState<AppMode>(AppMode.HOME);
  const [quizState, setQuizState] = useState<QuizState>(INITIAL_STATE);

  const currentQuestion = questions[quizState.currentQuestionIndex];
  const progress = Math.round(((quizState.currentQuestionIndex) / questions.length) * 100);

  const startQuiz = () => {
    setQuizState(INITIAL_STATE);
    setMode(AppMode.QUIZ);
  };

  const handleAnswer = (answer: string) => {
    const isCorrect = answer === currentQuestion.correctAnswer;
    setQuizState(prev => ({
      ...prev,
      answers: { ...prev.answers, [currentQuestion.id]: answer },
      score: isCorrect ? prev.score + 1 : prev.score
    }));
  };

  const handleNext = () => {
    if (quizState.currentQuestionIndex >= questions.length - 1) {
      setQuizState(prev => ({ ...prev, isFinished: true }));
    } else {
      setQuizState(prev => ({
        ...prev,
        currentQuestionIndex: prev.currentQuestionIndex + 1
      }));
    }
  };

  const handleRetry = () => {
    startQuiz();
  };

  // --- RENDER MODES ---

  if (mode === AppMode.REVIEW) {
    return <ReviewList questions={questions} onBack={() => setMode(AppMode.HOME)} />;
  }

  if (mode === AppMode.QUIZ && quizState.isFinished) {
    const percentage = Math.round((quizState.score / questions.length) * 100);
    return (
      <div className="min-h-screen flex items-center justify-center p-4">
        <div className="bg-white max-w-md w-full rounded-3xl shadow-xl border border-gray-100 p-8 text-center">
          <div className="w-20 h-20 bg-yellow-100 rounded-full flex items-center justify-center mx-auto mb-6">
            <Trophy className="w-10 h-10 text-yellow-600" />
          </div>
          <h2 className="text-3xl font-bold text-gray-900 mb-2">复习完成!</h2>
          <p className="text-gray-500 mb-8">你完成了所有题目的练习。</p>
          
          <div className="bg-gray-50 rounded-2xl p-6 mb-8">
            <div className="text-sm text-gray-500 font-medium uppercase tracking-wide mb-1">最终得分</div>
            <div className="text-5xl font-extrabold text-blue-600">{percentage}%</div>
            <div className="text-gray-400 mt-2 text-sm">
              答对 {quizState.score} / {questions.length} 题
            </div>
          </div>

          <div className="space-y-3">
            <Button onClick={handleRetry} className="w-full" size="lg">
              <RotateCcw className="w-5 h-5 mr-2" />
              重新开始
            </Button>
            <Button onClick={() => setMode(AppMode.HOME)} variant="outline" className="w-full">
              返回主页
            </Button>
          </div>
        </div>
      </div>
    );
  }

  if (mode === AppMode.QUIZ) {
    return (
      <div className="min-h-screen flex flex-col max-w-3xl mx-auto p-4 md:p-6">
        {/* Header Progress */}
        <div className="mb-6 flex items-center justify-between">
          <button onClick={() => setMode(AppMode.HOME)} className="text-sm font-medium text-gray-500 hover:text-gray-900">
            退出练习
          </button>
          <div className="flex-1 mx-6">
            <div className="h-2 bg-gray-200 rounded-full overflow-hidden">
              <div 
                className="h-full bg-blue-600 rounded-full transition-all duration-500 ease-out"
                style={{ width: `${progress}%` }}
              />
            </div>
          </div>
          <span className="text-sm font-medium text-gray-900">
            {quizState.currentQuestionIndex + 1}/{questions.length}
          </span>
        </div>

        <div className="flex-1 flex flex-col justify-center pb-10">
          <QuestionCard
            question={currentQuestion}
            selectedAnswer={quizState.answers[currentQuestion.id]}
            onSelectAnswer={handleAnswer}
            onNext={handleNext}
            isLast={quizState.currentQuestionIndex === questions.length - 1}
          />
        </div>
      </div>
    );
  }

  // HOME SCREEN
  return (
    <div className="min-h-screen flex flex-col items-center justify-center p-6 bg-gradient-to-b from-blue-50 to-white">
      <div className="max-w-md w-full space-y-8 text-center">
        <div className="space-y-2">
          <div className="inline-flex items-center justify-center w-16 h-16 rounded-2xl bg-blue-600 text-white shadow-lg shadow-blue-200 mb-4">
            <BookOpen className="w-8 h-8" />
          </div>
          <h1 className="text-3xl md:text-4xl font-extrabold text-gray-900 tracking-tight">
            数字化管理会计<br/>期末复习
          </h1>
          <p className="text-gray-500 text-lg">
            包含单选、判断及计算题综合练习
          </p>
        </div>

        <div className="grid gap-4 pt-4">
          <button 
            onClick={startQuiz}
            className="group relative flex items-center p-4 bg-white rounded-xl shadow-sm border border-gray-200 hover:border-blue-500 hover:shadow-md transition-all duration-200 text-left"
          >
            <div className="p-3 bg-blue-50 rounded-lg group-hover:bg-blue-600 transition-colors duration-200">
              <PlayCircle className="w-6 h-6 text-blue-600 group-hover:text-white" />
            </div>
            <div className="ml-4">
              <h3 className="font-bold text-gray-900">开始练习</h3>
              <p className="text-sm text-gray-500">顺序练习所有题目 ({questions.length}题)</p>
            </div>
          </button>

          <button 
            onClick={() => setMode(AppMode.REVIEW)}
            className="group relative flex items-center p-4 bg-white rounded-xl shadow-sm border border-gray-200 hover:border-purple-500 hover:shadow-md transition-all duration-200 text-left"
          >
            <div className="p-3 bg-purple-50 rounded-lg group-hover:bg-purple-600 transition-colors duration-200">
              <BarChart3 className="w-6 h-6 text-purple-600 group-hover:text-white" />
            </div>
            <div className="ml-4">
              <h3 className="font-bold text-gray-900">浏览题库</h3>
              <p className="text-sm text-gray-500">查看所有题目和答案解析</p>
            </div>
          </button>
        </div>
        
        <p className="text-xs text-gray-400 mt-8">
          Based on 2024 Exam Revision Materials
        </p>
      </div>
    </div>
  );
};

export default App;