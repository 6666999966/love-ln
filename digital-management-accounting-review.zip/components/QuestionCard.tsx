import React, { useState } from 'react';
import { Question, QuestionType } from '../types';
import { CheckCircle, XCircle, HelpCircle, BrainCircuit, ChevronRight } from 'lucide-react';
import { Button } from './Button';
import { getAIExplanation } from '../services/geminiService';

interface QuestionCardProps {
  question: Question;
  selectedAnswer?: string;
  onSelectAnswer: (answer: string) => void;
  onNext: () => void;
  isLast: boolean;
}

export const QuestionCard: React.FC<QuestionCardProps> = ({
  question,
  selectedAnswer,
  onSelectAnswer,
  onNext,
  isLast
}) => {
  const [isExplaining, setIsExplaining] = useState(false);
  const [aiExplanation, setAiExplanation] = useState<string | null>(null);

  const isAnswered = !!selectedAnswer;
  const isCorrect = selectedAnswer === question.correctAnswer;

  const handleExplain = async () => {
    if (aiExplanation) return; // Already fetched
    setIsExplaining(true);
    const explanation = await getAIExplanation(question);
    setAiExplanation(explanation);
    setIsExplaining(false);
  };

  const renderOptions = () => {
    const options = question.type === QuestionType.JUDGMENT 
      ? ["A", "B"] 
      : ["A", "B", "C", "D"];
    
    const optionLabels = question.type === QuestionType.JUDGMENT
      ? ["对 (A)", "错 (B)"]
      : question.options || [];

    return (
      <div className="space-y-3 mt-6">
        {options.map((optionKey, index) => {
          const isSelected = selectedAnswer === optionKey;
          const isCorrectOption = question.correctAnswer === optionKey;
          
          let buttonStyle = "border-gray-200 hover:bg-gray-50";
          if (isAnswered) {
             if (isCorrectOption) {
               buttonStyle = "bg-green-50 border-green-500 ring-1 ring-green-500";
             } else if (isSelected && !isCorrectOption) {
               buttonStyle = "bg-red-50 border-red-500 ring-1 ring-red-500";
             } else {
               buttonStyle = "opacity-50 border-gray-200";
             }
          } else if (isSelected) {
            buttonStyle = "border-blue-500 bg-blue-50 ring-1 ring-blue-500";
          }

          return (
            <button
              key={optionKey}
              onClick={() => !isAnswered && onSelectAnswer(optionKey)}
              disabled={isAnswered}
              className={`w-full text-left p-4 rounded-xl border transition-all duration-200 flex items-center justify-between group ${buttonStyle}`}
            >
              <div className="flex items-center gap-3">
                <span className={`w-8 h-8 flex items-center justify-center rounded-full text-sm font-semibold border ${
                   isAnswered && isCorrectOption ? 'bg-green-600 border-green-600 text-white' :
                   isAnswered && isSelected && !isCorrectOption ? 'bg-red-600 border-red-600 text-white' :
                   'bg-white border-gray-300 text-gray-500'
                }`}>
                  {optionKey}
                </span>
                <span className="text-gray-800 text-base md:text-lg">
                  {question.type === QuestionType.JUDGMENT 
                    ? (optionKey === 'A' ? '对' : '错') 
                    : (question.options?.[index] || `选项 ${optionKey}`)}
                </span>
              </div>
              
              {isAnswered && isCorrectOption && <CheckCircle className="w-6 h-6 text-green-600" />}
              {isAnswered && isSelected && !isCorrectOption && <XCircle className="w-6 h-6 text-red-600" />}
            </button>
          );
        })}
      </div>
    );
  };

  return (
    <div className="bg-white rounded-2xl shadow-sm border border-gray-100 overflow-hidden">
      <div className="p-6 md:p-8">
        <div className="flex items-center gap-2 mb-4">
          <span className="px-3 py-1 bg-blue-100 text-blue-700 text-xs font-semibold rounded-full uppercase tracking-wide">
            {question.type}
          </span>
          <span className="text-gray-400 text-sm font-medium">题目 #{question.id}</span>
        </div>
        
        <h2 className="text-xl md:text-2xl font-bold text-gray-900 leading-relaxed">
          {question.text}
        </h2>

        {renderOptions()}

        {isAnswered && (
          <div className="mt-8 animate-fade-in space-y-4">
            <div className={`p-4 rounded-lg border ${isCorrect ? 'bg-green-50 border-green-100' : 'bg-red-50 border-red-100'}`}>
              <div className="flex items-start gap-3">
                {isCorrect ? <CheckCircle className="w-5 h-5 text-green-600 mt-0.5" /> : <XCircle className="w-5 h-5 text-red-600 mt-0.5" />}
                <div>
                  <p className={`font-semibold ${isCorrect ? 'text-green-800' : 'text-red-800'}`}>
                    {isCorrect ? '回答正确！' : '回答错误'}
                  </p>
                  <p className="text-sm text-gray-600 mt-1">
                    正确答案是 <span className="font-bold">{question.correctAnswer === 'A' && question.type === QuestionType.JUDGMENT ? '对 (A)' : question.correctAnswer === 'B' && question.type === QuestionType.JUDGMENT ? '错 (B)' : question.correctAnswer}</span>
                  </p>
                </div>
              </div>
            </div>

            <div className="flex flex-wrap gap-3">
              <Button 
                onClick={onNext} 
                className="flex-1"
                size="lg"
              >
                {isLast ? '查看结果' : '下一题'} <ChevronRight className="w-5 h-5 ml-1" />
              </Button>

              <Button 
                variant="secondary" 
                onClick={handleExplain}
                disabled={isExplaining || !!aiExplanation}
                className="flex-shrink-0"
              >
                {isExplaining ? '思考中...' : (
                  <>
                    <BrainCircuit className="w-5 h-5 mr-2" />
                    AI 解析
                  </>
                )}
              </Button>
            </div>

            {(question.explanation || aiExplanation) && (
              <div className="mt-4 p-5 bg-blue-50 rounded-xl border border-blue-100 text-blue-900">
                <h4 className="flex items-center gap-2 font-semibold mb-2">
                  <HelpCircle className="w-4 h-4" />
                  解析
                </h4>
                <p className="text-sm leading-relaxed text-blue-800">
                  {aiExplanation || question.explanation}
                </p>
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
};