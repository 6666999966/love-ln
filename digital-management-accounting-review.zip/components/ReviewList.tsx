import React from 'react';
import { Question, QuestionType } from '../types';
import { Check, X } from 'lucide-react';

interface ReviewListProps {
  questions: Question[];
  onBack: () => void;
}

export const ReviewList: React.FC<ReviewListProps> = ({ questions, onBack }) => {
  return (
    <div className="max-w-4xl mx-auto p-4 md:p-6 pb-20">
      <div className="flex items-center justify-between mb-8 sticky top-0 bg-[#f3f4f6] py-4 z-10">
        <h2 className="text-2xl font-bold text-gray-900">题目总览</h2>
        <button 
          onClick={onBack}
          className="text-gray-600 hover:text-gray-900 font-medium"
        >
          返回首页
        </button>
      </div>

      <div className="space-y-4">
        {questions.map((q) => (
          <div key={q.id} className="bg-white p-5 rounded-lg border border-gray-200 shadow-sm hover:shadow-md transition-shadow">
            <div className="flex justify-between items-start mb-2">
              <span className="text-xs font-semibold text-gray-500 bg-gray-100 px-2 py-1 rounded">
                #{q.id} {q.type}
              </span>
              <span className="flex items-center text-sm font-bold text-green-600 bg-green-50 px-2 py-1 rounded">
                答案: {q.type === QuestionType.JUDGMENT ? (q.correctAnswer === 'A' ? '对' : '错') : q.correctAnswer}
              </span>
            </div>
            <p className="text-gray-800 font-medium mb-3">{q.text}</p>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-2 text-sm text-gray-600">
               {q.type !== QuestionType.JUDGMENT && q.options?.map((opt, idx) => {
                 const label = ["A", "B", "C", "D"][idx];
                 const isCorrect = label === q.correctAnswer;
                 return (
                   <div key={idx} className={`p-2 rounded ${isCorrect ? 'bg-green-50 text-green-800 font-medium' : ''}`}>
                     {label}. {opt}
                   </div>
                 )
               })}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};