export enum QuestionType {
  SINGLE_CHOICE = '单选题',
  JUDGMENT = '判断题',
  CALCULATION = '计算/综合题'
}

export interface Question {
  id: number;
  type: QuestionType;
  text: string;
  options?: string[]; // For single choice
  correctAnswer: string; // "A", "B", "C", "D" or "A"(True)/"B"(False) for judgment
  explanation?: string; // Pre-canned explanation if available
}

export interface QuizState {
  currentQuestionIndex: number;
  score: number;
  answers: Record<number, string>; // questionId -> userAnswer
  isFinished: boolean;
}

export enum AppMode {
  HOME = 'HOME',
  QUIZ = 'QUIZ',
  REVIEW = 'REVIEW'
}